import io
from flask import Flask, render_template, request, redirect, send_file,url_for,flash,session
from flask_sqlalchemy import SQLAlchemy
from passlib.hash import sha256_crypt
from werkzeug.utils import redirect
from datetime import datetime
from sqlalchemy import create_engine
import pandas as pd 
from io import BytesIO

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///todo.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key='login'

db = SQLAlchemy(app)
app.app_context().push()

db_url="sqlite:///todo.db"
engine=create_engine(db_url)


 
class contact_detail(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(250), unique=False, nullable=False)
    email = db.Column(db.String(250),unique=True, nullable=False)
    password = db.Column(db.String(250))

class blog(db.Model):
    index = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(250), unique=False, nullable=False)  # user name which is logged in ...
    blog_content = db.Column(db.String(250),unique=True, nullable=False) 
    title = db.Column(db.String(250),nullable=True)
    website_link=db.Column(db.String(250),nullable=True)
    github=db.Column(db.String(250),nullable=True)
    tech_use=db.Column(db.String(250),nullable=True)
    domain=db.Column(db.String(250),nullable=True)

#daily record of chicken
class daily(db.Model):
    index=db.Column(db.Integer, primary_key=True)
    current_datetime = datetime.now()
    death_no=db.Column(db.String(250),nullable=True)
    seed_packet=db.Column(db.String(250),nullable=True)
    death_file=db.Column(db.String(250),nullable=True)
    
class month(db.Model):
    index=db.Column(db.Integer, primary_key=True)
    chicken_came_date=db.Column(db.String(250),nullable=True)
    amount=db.Column(db.String(250),nullable=True)
    chicken_no=db.Column(db.String(250),nullable=True)
    total_packet=db.Column(db.String(250),nullable=True)
    total_death=db.Column(db.String(250),nullable=True)
    profit=db.Column(db.String(250),nullable=True)
    rasid=db.Column(db.String(250),nullable=True)

    




@app.route('/')
def home():
    projects=blog.query.all()
    return render_template('index.html',projects=projects)




@app.route('/signin',methods=["GET", "POST"])
def signin():
    if request.method=='POST':
        user=request.form['username']
        pwd=request.form['password']
        print("name o f the user is:  ",user)
        print(" password of user:  ",pwd)
        #from database 
        usr=contact_detail.query.filter_by(name=user).first()
        pas=usr.password
        print("form database usr and roll : ",usr.name,pas)
        if (sha256_crypt.verify(pwd,pas)):
             session['user']=user 
             return render_template('profile.html')
        else:
            return "Login Failed"
           

    return render_template('signin.html')



@app.route('/signup',methods=["GET", "POST"])
def Signp():
    if request.method=='POST':
        Roll=request.form['roll']
        nam=request.form['uname']
        email=request.form['email']
        
        password=request.form['password']
        print(nam,email,password) 
        encpassword=sha256_crypt.encrypt(password)
        entry=contact_detail(sno=Roll,name=nam,email=email,password=encpassword)
        db.session.add(entry)
        db.session.commit()
        flash('refistration done succesfully')
        return redirect(url_for('signin'))
    return render_template('signup.html')


@app.route('/daily_add',methods=['GET','POST'])
def daily_add():
    if 'nm' in session:
        print('hiii in the session ')
        if request.method=='POST':
            dt=request.form['date']
            dead=request.form['death']
            seeds=request.form['seed_packet']
            df=request.files['death_file']
            
            df.save(df.filename)
            content=df.read()

            entry=daily(current_datetime=dt,death_no=dead,seed_packet=seeds,death_file=df.filename)
            db.session.add(entry)
            db.session.commit()
            pt=daily.query.all()
            nm=session['nm']
            return render_template('dashboard.html',pt=pt,name=nm,file=df)
        else:
            pt=daily.query.all()
            nm=session['nm']
            return render_template('dashboard.html',pt=pt,name=nm)
    print('session exipred !! some miskstke ')       
    return render_template('user1.html')



@app.route('/daily_add/<int:id>')
def download_file(id):
    file = daily.query.get_or_404(id)
    ck=daily.query.filter_by(index=id).first()
    
    return send_file(io.BytesIO(ck.death_file), as_attachment=True, download_name='Coles_Resume_Template_.pdf')



@app.route('/month_add',methods=['GET','POST'])
def month_add():
    if 'nm' in session:
        nm=session['nm']
        if request.method=='POST':
            dt=request.form['chicken_came_date']
            at=request.form['investment']
            cn=request.form['chicken_no']
            tp=request.form['total_packet']
            td=request.form['total_death']
            pf=request.form['profit']
            rs=request.form['rasid']
            entry=month(chicken_came_date=dt,amount=at,chicken_no=cn,total_packet=tp,total_death=td,profit=pf,rasid=rs)
            db.session.add(entry)
            db.session.commit()
            pt=month.query.all()
            nm=session['nm']
            
            return render_template('dashboard1.html',pt=pt,name=nm)
            
        else:
            nm=session['nm']
            pt=month.query.all()
            return render_template('dashboard1.html',name=nm,pt=pt)
    return 'hhhiii'

@app.route('/addpost',methods=['GET','POST'])
def addpost():
   if 'user' in session:
    nm=session['user']
    if request.method=='POST':
        title=request.form['title']
        blog_content=request.form['blog_content']
        website=request.form['web']
        github=request.form['github']
        tech=request.form['tech']
        domain=request.form['domain']
        entry=blog(email=nm,blog_content=blog_content,title=title,website_link=website,github=github,tech_use=tech,domain=domain)
        db.session.add(entry)
        db.session.commit()
        return render_template('profile.html') 
    else:
        return render_template('addpost.html')
        
  



@app.route('/logout')
def logout():
    session.pop('user',None)
    session.pop('nm', None)
    session.pop('logged_in', None)
    session.pop('admin',None)
    return render_template('user1.html')


@app.route('/about')
def About():
    return render_template('about.html')


@app.route('/blog')
def Blog():
    return render_template('blog.html')


@app.route('/services')
def Service():
    return render_template('services.html')


@app.route('/price')
def price():
    return render_template('pricing.html')


@app.route('/get_quote')
def get_quote():
    return render_template('get-a-quote.html')



@app.route('/contact')
def Contact():
    return render_template('contact.html')



@app.route('/profile')
def profile():
    if 'user' in session :
        print("name of the useer is :  ",session['user'])
        nm=session['user']
        #posts=Blog.query.filter_by(email=session['user']).all()
        #posts=Blog.query.filter_by(email='raj')
        posts=blog.query.filter_by(email=session['user'])
        blog_posts=blog.query.all()
        return render_template('profile.html',blog_post=blog_posts,posts=posts,nm=nm)
    else:
        return render_template('signin.html')
    

@app.route('/user1',methods=['GET','POST'])
def user1():
    if request.method=='POST':
        nm=request.form['username']
        em=request.form['email']
        
        if nm=='manish' and em=='manish8210@gmail.com':
            #posts=daily.query.all()
            session['nm']=nm 
            session['logged_in'] = True

            return redirect('/daily_add')
            #return render_template('dashboard.html',nm=nm)
    else:
        return render_template('user1.html')



@app.route('/admin',methods=['GET','POST'])
def admin():
    if request.method=='POST':
        nm=request.form['username']
        em=request.form['email']
        
        if nm=='guddu' and em=='guddu@gmail.com':
            #posts=daily.query.all()
            session['nm']=nm 
            session['logged_in'] = True
            session['admin']=True
            return redirect('/month_add')
            #return render_template('dashboard.html',nm=nm)
        else:
            return 'try with correct password and email'
    else:
        return render_template('admin.html')


    

@app.route('/editpost/<int:id>')
def editpost(id):
    if 'user' in session:
        nm=session['user']
        user=blog.query.filter_by(index=id).first()
        return render_template('editpost.html',username=nm,account=user)
    else:     
        return render_template('signin.html')



@app.route('/editmonth/<int:id>')
def editmonth(id):
    if 'nm' in session:
        nm=session['nm']
        user=month.query.filter_by(index=id).first()
        return render_template('editmonth.html',username=nm,account=user)
    else:     
        return render_template('index.html')



@app.route('/editdaily/<int:id>')
def editdaily(id):
    if 'nm' in session:
        nm=session['nm']
        user=daily.query.filter_by(index=id).first()
        return render_template('editdaily.html',username=nm,account=user)
    else:     
        return render_template('index.html')




@app.route('/updatepost/<int:id>',methods=["GET", "POST"])
def updatepost(id):
    if 'user' in session:
        nm=session['user']
        if request.method=='POST':
            user=blog.query.filter_by(index=id).first()
            user.title=request.form['title']
            user.blog_content=request.form['blogdata']
            db.session.add(user)
            db.session.commit()
            return redirect('/profile')
        else:
            return "try again"
    else:   
        return render_template('login.html')



@app.route('/month_update/<int:id>',methods=["GET", "POST"])
def month_update(id):
    if 'nm' in session:
        nm=session['nm']
        if request.method=='POST':
            user=month.query.filter_by(index=id).first()
            user.chicken_came_date=request.form['chicken_came_date']
            user.amount=request.form['investment']

            user.amount=request.form['investment']
            user.chicken_no=request.form['chicken_no']
            user.total_packet=request.form['total_packet']
            user.total_death=request.form['total_death']

            user.profit=request.form['profit']
            user.rasid=request.form['rasid']


            
            db.session.add(user)
            db.session.commit()
            return redirect('/month_add')
        else:
            return "try again"
    else:   
        return render_template('index.html')


@app.route('/daily_update/<int:id>',methods=["GET", "POST"])
def daily_update(id):
    if 'nm' in session:
        nm=session['nm']
        if request.method=='POST':
            user=daily.query.filter_by(index=id).first()

            user.current_datetime=request.form['current_datetime']
            user.death_no=request.form['death_no']

            user.seed_packet=request.form['seed_packet']
            user.death_file=request.form['death_file']
            
            db.session.add(user)
            db.session.commit()
            return redirect('/daily_add')
        else:
            return "try again"
    else:   
        return render_template('index.html')



@app.route('/delete/<int:id>')
def deletepost(id):
    if 'user' in session:
        nm=session['user']
        user=blog.query.filter_by(index=id).first()
        db.session.delete(user)
        db.session.commit()
        return redirect('/profile')
    else:
        return render_template('signin.html')


@app.route('/delete_daily/<int:id>')
def delete_daily(id):
    if 'nm' in session:
        data=daily.query.filter_by(index=id).first()
        db.session.delete(data)
        db.session.commit()
    return redirect('/daily_add')


@app.route('/delete_month/<int:id>')
def delete_month(id):
    if 'nm' in session:
        data=month.query.filter_by(index=id).first()
        db.session.delete(data)
        db.session.commit()
    return redirect('/month_add')



@app.route('/download-excel')
def download_excel():
    # Retrieve data from the database table
    data = blog.query.all()

    # Create a Pandas DataFrame from the retrieved data
    data_dict = [{'column1': item.title, 'column2': item.blog_content} for item in data]
    df = pd.DataFrame(data_dict)

    # Create an Excel writer in memory
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='openpyxl')
    df.to_excel(writer, sheet_name='YourTableData', index=False)
    writer.close()
    output.seek(0)

    # Serve the Excel file as a downloadable attachment
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', as_attachment=True, download_name='table_data.xlsx')


if __name__=="__main__":
        app.run(debug=True,host='0.0.0.0')
